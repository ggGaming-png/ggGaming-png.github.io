% CORRESPONDENCE INFORMATION
%    This code is written by Xiaojun Chen and Guowen Yuan

%     Xiaojun Chen :  College of Computer Science and Software, Shenzhen University, Shenzhen 518060, China
%                                   Email:   xjchen@szu.edu.cn
%     Guowen Yuan:    College of Computer Science and Software, Shenzhen University, Shenzhen 518060, China 
%                                   Email:   gwyuan93@qq.com

%   WORK SETTING:
%    This code has been compiled and tested by using matlab R2015a

%  For more detials, please see the manuscript:
%   Xiaojun Chen, Guowen Yuan, Wenting Wang, Feiping Nie, Xiaojun Chang, and Joshua Zhexue Huang.
%   Local Adaptive Projection Framework for Feature Selection of Labeled and Unlabeled Data 
%   IEEE Transactions on Neural Netwrok and Learning System (T-NNLS), DOI:10.1109/TNNLS.2018.2830186, 2018.

%   Last Modified: Oct. 24, 2018, By Shiming Xiang

% =========================================================================
% A Demo  Example to run the code for feature selection 
% =========================================================================

load('glass.mat', 'X', 'Y');

gamma=1;
m = 3;
k = 3;

[rank_slap,~,~,~]=SLAP(X',Y,m,gamma,k);
[rank_ulsp,~,~,~]=ULAP(X',m,gamma,k);


% perform other tasks, ...........


