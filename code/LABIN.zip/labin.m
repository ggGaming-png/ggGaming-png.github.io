function[finalInd,finalS,finalObj]=tt(X,m,k,c,inter_max_iter,out_max_iter)
% X: data
% m: number of anchors
% k: number of neighborhoods
% c: number of clusters
n=size(X,1);

B = constructAnchorDistance_PKN(X,m, k);

%m=size(B,2);
P=B*spdiag((sum(B,1)).^-0.5);
Q=[P,ones(n,1)];
[U_q,S_q,V_q]=svd(Q,'econ');


% random init S and Y
labels= randsrc(n, 1, 1:c);
Y=sparse(1:n,labels,1);
V=sum(Y,1);
Vnorm2=sum(V.^2);

s=rand(1);
%s=0;
% obj1=s/2*trace(Y*(Y'*Y)*Y')-trace((Y'*P)*(P'*Y));
% obj2=trace(Y'*Q*spdiag([-1*ones(1,m),s/2*ones(1,1)])*Q'*Y);

%A0=P*P';
%s=trace(Y'*A0*Y)/(Vnorm2);
%disp(datestr(now,0));
%finalObj=sum(sum((A0-s*(Y*Y')).^2));
%disp(datestr(now,0));
%disp('###');
finalObj=inf;
finalInd=Y;
finalS=s;
obj_old=finalObj;

for iter_i=1:out_max_iter
%% 1.solve Y with s fixed
    tt=spdiag([ones(1,m),-s/2]);

    [Omiga,eig_val]=eig(S_q*V_q'*tt*V_q*S_q');
    [~,idx]=sort(diag(eig_val),'descend');
    
    eig_vector=U_q*Omiga;
    U=eig_vector(:,idx(1:c));
    Yopt=U;
   % disp(['  inter-obj-Yopt:',num2str(getObj(P,Yopt,s))]);
    for iter_ii=1:inter_max_iter
        [U_y,~,V_y]=svd(Y'*Yopt);
        %R=V_y*U_y';
        %G=Yopt*R;
        [~,ind]=max(Yopt*(V_y*U_y'),[],2);
        Y=zeros(n,c);
        Y(sub2ind([n,c],1:n,ind'))=1;
        %obj=sum(sum((A0-s*(Y*Y')).^2));
        obj=getObj(P,Y,s);
        if  finalObj>obj
            finalInd=Y;
            finalObj=obj;
            finalS=s;
        end
        
        %obj1=-s*s/2*trace(Y*(Y'*Y)*Y')+s*trace((Y'*P)*(P'*Y));
        disp(['  inter-obj:',num2str(obj)]);        
        if abs((obj-obj_old)/(obj+10^-100))<1e-8 ||(iter_ii==inter_max_iter)
            obj_old=obj;
            %disp([num2str(iter_i),':max_inter_iteration:',num2str(iter_ii)]);
            break;
        else
            obj_old=obj;
        end     
    end

% [~,labels]=max(Y,[],2);
% metrics = ClusteringMeasure(double(truth), double(labels));
% disp(metrics);
%% 2.solve s with Y fixed
V=sum(Y,1);
Vnorm2=sum(V.^2);
%s=trace(Y'*A0*Y)/Vnorm2;
s=trace((Y'*P)*(P'*Y))/(Vnorm2);
%obj=sum(sum((A0-s*(Y*Y')).^2));
obj=getObj(P,Y,s);
disp(['   ',num2str(obj)]);
if  finalObj>obj
    finalInd=Y;
    finalObj=obj;
    finalS=s;
end
if abs((obj-obj_old)/obj)<1e-8
    break;
else
    obj_old=obj;
end   
        
end
end

function[obj]=getObj(P,Y,s)
%disp(['obj-be-',datestr(now,0)]);
obj=-s*s*sum(diag(Y'*Y).^2)+2*s*trace((Y'*P)*(P'*Y));
%obj1=trace(P*(P'*P)*P')+s*s*trace(Y*(Y'*Y)*Y')-2*s*trace((Y'*P)*(P'*Y));

%disp(['obj-end-',datestr(now,0)]);
end