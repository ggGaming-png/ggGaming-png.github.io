function [finalY, finalS, finalObj, obj, Etas] = EBMC(A, c, NITR, rho, r, init_Y, ratio)
%A: similarity matrix
%A = sparse(A);
%c: Number of clustering
n = size(A, 1);

if nargin<3
    NITR = 100;
end

if nargin<4 || isnan(rho)
    rho = 4;
end

if nargin <5 || isnan(r)
    r = 10;
end

NTR2 = 10;
%% init Y Ay kmeans
if nargin < 6
    Y0 = kmeans(A, c, 'emptyaction','drop', 'MaxIter', 300);
    Y=n2nc(Y0);
end
Y = init_Y;

% update S
S=eye(c);
for L = 1:c
    yl = Y(:, L);
    d=yl'*A*yl;
    if d==0
        S(L,L) = 0;
    else
        S(L,L) = (yl'*A*yl)/(sum(yl)^2);
    end
end


etaBase=max(2*diag(S)+n*diag(S).^2);


H = zeros(n, c);
obj=zeros(NITR,NTR2+1);

finalY = Y;
% finalObj = F22norm(A-Y*S*Y');
finalObj = 2*trace(S*Y'*A*Y) - trace(S^2*Y'*ones(n,n)*Y);
obj(1,1) = finalObj;
finalS=S;
Etas = zeros(NITR, 1);
for it = 1:NITR
    Y_old = Y;
    % update eta
    if nargin < 7
        eta = etaFunction(it, etaBase,  rho, r);
    else
        eta = etaBase*ratio;    
    end
    Etas(it) = eta;
    %% update Y
    itr_best_Y = Y;
    itr_best_obj = 0;
    for itr = 1:NTR2
        for L = 1:c
            yl = Y(:, L);
            H(:, L) = 2*S(L,L)*A*yl - repmat(S(L,L)^2*sum(yl),[n 1])+ eta*yl;
        end
        [~,ind]=max(H,[],2);
        converged = true;
        for i = 1:n
            if Y(i,ind(i))~=1
                Y(i, :) = 0;
                Y(i, ind(i)) = 1;
                converged = false;
            end
        end
        
        obj(it,itr+1)=2*trace(S*Y'*A*Y) - trace(S^2*Y'*ones(n,n)*Y);
        if obj(it, itr+1) > itr_best_obj
            itr_best_obj = obj(it, itr+1);
            itr_best_Y = Y;
        else
            Y = itr_best_Y;
        end
        
        
        if converged
            break;
        end
        
    end

    % update S
    for L = 1:c
        yl = Y(:, L);
        d=sum(yl)^2;
        if d==0
            S(L,L) = 0;
        else
            S(L,L) = yl'*A*yl/d;
        end
    end
    %update etaBase
    etaBase=max(2*diag(S)+n*diag(S).^2);
    
    cobj=2*trace(S*Y'*A*Y) - trace(S^2*Y'*ones(n,n)*Y); 
    obj(it+1,1)=cobj;
    
    if ~ismember(0,sum(Y)) && finalObj < cobj
        finalY = Y;
        finalObj = cobj;
        finalS = S;
    end
 
    if it>10 && isequal(Y_old,Y)
        break
    end
end

end