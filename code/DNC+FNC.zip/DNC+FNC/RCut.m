function Y=RCut(A,c,repeat)
% A: similarity matrix

if nargin<3
    repeat=100;
end

D = diag(sum(A));
n=size(A,1);
Ini = zeros(n, repeat);
for jj = 1 : repeat
    Ini(:, jj) = randsrc(n, 1, 1:c);
end;

[Fg, ~] = eig1(full(D-A), c, 0, 1);
Fg = Fg./repmat(sqrt(sum(Fg.^2,2)),1,c);  %optional
Y = tuneKmeans(Fg',c, Ini);
end