
% max_Tr{(Y'DY)^(-1/2)Y'G}, G = AY(Y'DY)^(-1/2)
function [finalY,finalObj, Obj,lambda,changed] = DNC(A,c,lambda, Y, NITR )
% A: similarity matrix
% c: number of clusters
% lambda: regularizatrion parameter
% Y: initial Inicator matrix
% NITR: max iteratios to run

n = size(A,1);
D = diag(sum(A, 2));
D2=D^-0.5;
M=D2*A*D2;

if nargin<3 || isnan(lambda)
    lambda=0;
    meg=min(eig(M));
    if meg<=0
        lambda=-meg+eps;
    end
    M=M+lambda*eye(n);
else
    M=M+lambda*eye(n);
end

if nargin < 4
    Y0 = kmeans(A, c, 'emptyaction','drop', 'MaxIter', 300);
    Y=n2nc(Y0);
end

if nargin<5
    NITR=100;
end


Obj = zeros(NITR+1,1);
changed = zeros(NITR,1);


D2=D^0.5;
scaled=Y'*D*Y+ eps*eye(c);
F = D2*Y*(scaled^-0.5);
G = M*F;
%% check objective function value
Obj(1)= trace(F'*G);

[~,ind]=sort(diag(D),'ascend');
%ind=1:n;

for iter = 1:NITR
    
    %    fix G,update Y
    D2G=D2*G;
    yg = diag(Y'*D2G);
    ydy = diag(Y'*D*Y+ eps*eye(c));
    
%     objj=zeros(n,n);
    for it=1:n
        converged=0;
        for i=1:n
            N1=yg'+D2G(ind(i),:).*(1-Y(ind(i),:));
            DE1=ydy'+D(ind(i),ind(i))*(1-Y(ind(i),:));
            
            N2=yg'-D2G(ind(i),:).*Y(ind(i),:);
            DE2=ydy'-D(ind(i),ind(i))*Y(ind(i),:);
            
%             inc=N1./sqrt(DE1)-N2./sqrt(DE2);
%             
%             act=zeros(1,c);
%             Y_new=Y;
%             for j=1:c
%                 Y_new(ind(i),:)=0;
%                 Y_new(ind(i),j)=1;
%                 scaled=Y_new'*D*Y_new+ eps*eye(c);
%                 F = D2*Y_new*(scaled^-0.5);
%                 o1= trace(F'*G);
%                 Y_new(ind(i),j)=0;
%                 scaled=Y_new'*D*Y_new+ eps*eye(c);
%                 F = D2*Y_new*(scaled^-0.5);
%                 o0= trace(F'*G);
%                 act(j)=o1-o0;
%             end
%             
%             if sum(inc-act)>0.0001
%                 a=1;
%             end
            
            [~,id1]=max(N1./sqrt(DE1)-N2./sqrt(DE2));
            id0=find(Y(ind(i),:)==1);
            if id1~=id0
                Y(ind(i),:)=0;
                Y(ind(i),id1)=1;
                yg(id0)=yg(id0)-D2G(ind(i),id0);
                yg(id1)=yg(id1)+D2G(ind(i),id1);
                ydy(id0)=ydy(id0)-D(ind(i),ind(i));
                ydy(id1)=ydy(id1)+D(ind(i),ind(i));
                converged=converged+1;
                
%                 if sum(yg-diag(Y'*D2G))>0.0001
%                     a=1;
%                 end
%                 
%                 if   sum(ydy -diag(Y'*D*Y+ eps*eye(c)))>0.0001
%                     a=1;
%                 end
%                 
%                 
%                 scaled=Y'*D*Y+ eps*eye(c);
%                 F = D2*Y*(scaled^-0.5);
%                 objj(it,converged)= trace(F'*G);
            end
        end
        
        if converged==0
            break;
        end
    end
    
    changed(iter)=it;
    
    %% fix Y, update G
    scaled=Y'*D*Y+ eps*eye(c);
    
    F = D2*Y*(scaled^-0.5);
    G = M*F;
    %% check objective function value
    Obj(iter+1)= trace(F'*G);
    if isnan(Obj(iter+1))
        finalY = Y;
        finalObj=Nan;
        break;
    end
    if iter ==1
        maxObj=Obj(iter+1);
        finalY = Y;
        finalObj=maxObj;
    else
        if ~isnan(Obj(iter+1)) && Obj(iter+1) >= maxObj
            maxObj=Obj(iter+1);
            finalObj=maxObj;
            finalY = Y;
        end
    end
    if iter>2 && abs((Obj(iter+1)-Obj(iter))/Obj(iter+1))<1e-10
        break;
    end
    if iter>30 && sum(abs(Obj(iter-8:iter-4)-Obj(iter-3:iter+1)))<1e-10
        break;
    end
end
end






