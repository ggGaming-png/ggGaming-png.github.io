
function[Va2,U]= Nystrom2(A,B,sIndices,k)

n=size(A,2)+size(B,2);
L=size(sIndices,2);

l2=1:n;
l2(sIndices)=[];

a=A*ones(L,1);
b1=B*ones(n-L,1);
b2=B'*ones(L,1);
D=[a+b1;b2+B'*A^-1*b1];D=D';
D1=sparse(1:L,1:L,D(1,1:L).^-0.5);
D2=sparse(1:n-L,1:n-L,D(1,L+1:n).^-0.5);
clear D;
Aa=D1*A*D1;
Aa1=Aa^-0.5;
Ba=D1*B*D2;
R=Aa+Aa1*Ba*Ba'*Aa1;
[UR,VR,~]=eig(R);
VR=VR*ones(L,1);
[VR,Index]=sort(VR,1,'descend');
VR=diag(VR);
UR=UR(:,Index);

Va1=[Aa;Ba']*Aa1*UR(:,1:k)*(VR(1:k,1:k))^-0.5;
Va2=Va1.*repmat(sqrt(sum((Va1.*Va1),2)).^-1,1,k);
Va2=real(Va2);
clear Va1;
%relabel 
U(sIndices,:)=Va2(1:L,:);
U(l2,:)=Va2(L+1:n,:);
end