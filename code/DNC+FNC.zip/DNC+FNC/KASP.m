function [ label ] = KASP( X,m,c,repeat1,repeat2)
% X: dim*n matrix, each column is a data point
%   Detailed explanation goes here
if nargin<3
    c=10;
end

if nargin<4
    repeat1=100;
end

if nargin<5
    repeat2=100;
end

n=size(X,2);

%step1 kmeans to X 
%[IndicatorM,center,~,~,~]=litekmeans(X,m);
repeat=repeat1;

% [IndicatorM,~,~,center,obj]=kmeans(X,m);
[IndicatorM,center,~,sumD,~]=litekmeans(X',m);
obj=sum(sumD);
for index =1:repeat-1
%     [tIndicatorM,~,~,tcenter,tobj]=kmeans(X,m);
    [tIndicatorM,tcenter,~,sumD,~]=litekmeans(X',m);
    tobj=sum(sumD);
    if(tobj<obj)
        obj=tobj;
        IndicatorM=tIndicatorM;
        center=tcenter;
    end
end
%disp(obj);
%disp(toc);
%step2 spectral to m
repeat=repeat2;

W=constructW_PKN(center',size(center,1)-2);
IndicatorK=NCut(W,c,repeat);
label=zeros(n,1);
for index=1:n
    label(index,1)=IndicatorK(IndicatorM(index));
end

end

