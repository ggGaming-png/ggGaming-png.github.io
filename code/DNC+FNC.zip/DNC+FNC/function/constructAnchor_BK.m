function [ biCentSet ] = constructAnchor_BK( X,m, gamma)
% CONSTRUCTANCHOR Summary of this function goes here
%   Detailed explanation goes here

if nargin < 3
    gamma=0.01;
end
[biCentSet,~] = BalancedKmeans(X, m, gamma);
% showCluster(biDataSet,biK,biCentSet,biClusterAssume);


end

