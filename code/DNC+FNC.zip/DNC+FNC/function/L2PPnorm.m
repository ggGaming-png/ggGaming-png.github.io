% compute l^{p}_{2,p} norm
% ||A||^{p}_{2,p}
function v = L2PPnorm(A,p, epsilon)
% a: each column is a data
% d:  norm value
if nargin<3
    epsilon=0;
end

v=sum((sum(A.*A,2)+epsilon).^(p/2));