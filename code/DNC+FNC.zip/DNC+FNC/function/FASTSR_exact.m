% min_{G=Ind,Q'*Q=I} || D^{0.5}*G*(G'*D*G)^{-0.5} - F0*Q ||^2
function [Gsr4, obj_sr4] = FASTSR_exact(F0, G,NITR)

[n,class_num] = size(F0);

if nargin < 2
    StartInd = randsrc(n,1,1:class_num);
    G = n2nc(StartInd);
end;

if nargin<3
    NITR=30;
end

Gsr4 = G;
obj_sr4=zeros(NITR,1);
for iter = 1:NITR
    Gd = Gsr4*(Gsr4'*Gsr4+eps*eye(class_num))^-0.5;
    [U,~, V] = svd(F0'*Gd);
    Q = U*V';
    FQ = F0*Q;
    [~,g] = max(FQ,[],2);
    Gsr4 = TransformL(g, class_num);
    nn = sum(Gsr4.*(Gsr4));
    s = sum(FQ.*(Gsr4));
    [fq] = max(FQ,[],2);
    [~,idxi] = sort(fq);
    for it = 1:4
        converged=true;
        for ii = 1:n
            i = idxi(ii);
            hi = FQ(i,:);
            gi = Gsr4(i,:);
            [~,id0] = max(gi);
            ss = (s+(1-gi).*(hi))./sqrt(nn+(1-gi)) - (s-gi.*(hi))./(sqrt(nn-gi)+eps);
            [~, id] = max(ss);
            if id~=id0
                converged=false;
                gi = zeros(1,class_num);
                gi(id) = 1;
                Gsr4(i,:) = gi;
                nn(id0) = nn(id0) - 1;  nn(id) = nn(id) + 1;
                s(id0) = s(id0) - FQ(i,id0);  s(id) = s(id) + FQ(i,id);
            end;
        end;
        if converged
            break;
        end
    end;
    Gd = Gsr4*(Gsr4'*Gsr4+eps*eye(class_num))^-0.5;
    obj_sr4(iter) = trace((Gd-FQ)'*(Gd-FQ));
    if iter>1 && abs((obj_sr4(iter)-obj_sr4(iter-1))/obj_sr4(iter))<1e-6
        break;
    end
end;


