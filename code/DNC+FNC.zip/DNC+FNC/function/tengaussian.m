function [X,x, y, n1] = tengaussian(num, var1, fea_n, noise)
%X:num *( fea_n+2)
%y:num * 1
%n1:num/c
n1 = floor(num/10);
C = [var1,0;0,var1];%Э����
u = [[-1,0];[-3,0];[-2,1];[-2,-1];[1,0];[3,0];[2,1];[2,-1];[0,1];[0,-1]];
X = [];
x = cell(10,1);
for i=1:length(u)
    m = u(i,:);
    x{i} = mvnrnd(m,C,n1);
    X = [X;x{i}];
end
z = 5*noise*randn(10*n1,fea_n);
X = [X,z];
y = [ones(n1,1);2*ones(n1,1);3*ones(n1,1)];

