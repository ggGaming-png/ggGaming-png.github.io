% construct similarity matrix with probabilistic k-nearest neighbors. It is a parameter free, distance consistent similarity.
function W = constructW_PN(X, X2)
% X: each column is a data point
% X2: each column is a data point
% W: similarity matrix


n = size(X,2);
D = L2_distance(X, X2);
[~, idx] = sort(D, 2); % sort each row

n2=size(X2,2);
W = zeros(n,n2);
for i = 1:n
    id = idx(i,:);
    di = D(i, id);
    W(i,id) = (di(n2)-di)/(n2*di(n2)-sum(di(1:n2))+eps);
end;

W(isnan(W))=1;





