function [finalInd, Ind, SD, SSE] = tuneBalancedKmeans(X,c, lambda,nRepeat)
%X: dim*n matrix, each column is a data point

if nargin<3
    lambda= logspace(-4,0,5);
end

if nargin<4
    nRepeat = 2;
end

n=size(X,2);
Ind=zeros(nRepeat,n);
SD=zeros(nRepeat,1);
SSE=zeros(nRepeat,1);

index=1;
minResult=NaN;
for ii = 1 : nRepeat
    for jj=1:length(lambda)
        [Ind(:, index), F,H,~,~] = BalancedKmeans(X, c,lambda(jj));
        cc=sum(F,1);
        SD(index)=std(cc);
        SSE(index)=norm(X-H*F','fro')^2;
        mm=SD(index)*SSE(index);
        if index>1 || minResult>mm
            minResult=mm;
            finalInd = Ind(:, index);
        end;
        index=index+1;
    end
end;

end

