function [ points ] = ProjectLine( minx,maxx,miny,maxy,px,py )
points=zeros(2,2);
if px<py
      width=(maxy-miny)*px/py;
      points=[(minx+maxx-width)/2,(minx+maxx+width)/2;miny,maxy];
else
      heigh=(maxx-minx)*py/px;
      points=[minx,maxx;(miny+maxy-heigh)/2,(miny+maxy+heigh)/2];
end

end

