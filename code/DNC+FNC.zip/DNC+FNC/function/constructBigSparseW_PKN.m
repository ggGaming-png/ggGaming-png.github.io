% construct similarity matrix with probabilistic k-nearest neighbors. It is a parameter free, distance consistent similarity.
function W = constructBigSparseW_PKN(X, k, issymmetric)
% X: each column is a data point
% k: number of neighbors
% issymmetric: set W = (W+W')/2 if issymmetric=1
% W: similarity matrix

if nargin < 3
    issymmetric = 1;
end;
if nargin < 2
    k = 10;
end;

[~, n] = size(X);

W=spalloc(n,n,n*k);
for i = 1:n
   
    dis=L2_distance(X(:,i),X);

    [~, idx] = sort(dis);
    id = idx(2:k+2);
    di = dis(id);
    W(i,id) = (di(k+1)-di)/(k*di(k+1)-sum(di(1:k))+eps);
end;

W(isnan(W))=1;

if issymmetric == 1
    W = (W+W')/2;
end;





