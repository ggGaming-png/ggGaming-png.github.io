function Y=NCut(A,c,repeat)
% A: similarity matrix

if nargin<3
    repeat=100;
end

D = diag(sum(A)+eps);
n=size(A,1);

Ini = zeros(n, repeat);
for jj = 1 : repeat
    Ini(:, jj) = randsrc(n, 1, 1:c);
end;

Dd = diag(D);
Dn = spdiags(sqrt(1./Dd),0,n,n);
An = Dn*A*Dn;
An = (An+An')/2;
[Fng, ~] = eig1(full(An), c, 1, 1);
Fng = Fng./repmat(sqrt(sum(Fng.^2,2)),1,c);  %optional
Y = tuneKmeans(Fng', c, Ini);
end