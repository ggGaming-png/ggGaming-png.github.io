
function [bestY, Obj,changed] = FNC(X,c,m,k,init,NITR)
% X: [d n] data matrix, where n is the number of objects and d is the
% c: number of clusters
% m: number of anchors
% k: number of neighborhoods
% lambda: regularizatrion parameter
% init: initialization method -'kmeans', 'random' and 'bkm'
% NITR: max iteratios to run

[~,n] = size(X);


if nargin<5
    init = 'kmeans';
end

if nargin<6
    NITR=100;
end

switch init
    case 'kmeans'
        Y0 = kmeans(X', c);
        Y=n2nc(Y0);
    case 'bkm'
        Y0=tuneBalancedKmeans(X,c);
        Y=n2nc(Y0);
    case 'random'
%         Initialize the indicator matrix F randomly. 
        StartInd = randsrc(n,1,1:c);
        Y = zeros(n,c);
        for i = 1:n
            Y(i,StartInd(i))=1;
        end
end


Obj = zeros(NITR,1);
changed = zeros(NITR,1);

B = constructAnchorDistance_PKN(X,m, k);
B = sparse(B);
Delta1=diag(sum(B,1))^-1;
F=Y*(Y'*Y+ eps*eye(c))^-0.5;
R=Delta1*B'*F;
G = B*R+eps*F;
for iter = 1:NITR
    %     yg = diag(Y'*G)';
    yg = diag(Y'*G)';
    yy = diag(Y'*Y+ eps*eye(c))';
    %    fix G,update Y
    for it = 1:10
        converged = true;
        for i = 1:n
            yi = Y(i,:);
            gi = G(i,:);
            [~,id0] = max(yi);
            ss = (yg + gi.*(1-yi))./sqrt(yy + 1-yi) - (yg - gi.*yi)./sqrt(yy - yi);
            [~,id] = max(ss(:));
            if id ~= id0
                converged = false;
                changed(iter)=changed(iter)+1;
                %% update Y
                yi = zeros(1,c);
                yi(id) = 1;
                Y(i,:) = yi;
                %% update ydy
                yy(id0) =yy(id0) - 1;
                yy(id) =yy(id) + 1;
                %% update G
                %             AYi = A(i,:)*Y;
                %             gi = AYi*(diag(ydy))^-0.5;
                %             G(i,:) = gi;
                %% update YG
                yg(id0) =yg(id0) - gi(id0);
                yg(id) = yg(id) + gi(id);
            end
        end
        if converged
            break;
        end
    end
    %% fix Y, update G
    F=Y*(Y'*Y+ eps*eye(c))^-0.5;
    R=Delta1*B'*F;
    G = B*R+eps*F;   
    
    %% check objective function value
    Obj(iter)= trace(F'*G);
    if iter ==1
        maxObj=Obj(iter);
        bestY = Y;
    else
        if ~isnan(Obj(iter)) && Obj(iter) >= maxObj
            maxObj=Obj(iter);
            bestY = Y;
        end
    end
    if iter>2 && abs((Obj(iter)-Obj(iter-1))/Obj(iter))<1e-10
        break;
    end
    if iter>30 && sum(abs(Obj(iter-9:iter-5)-Obj(iter-5+1:iter)))<1e-10
        break;
    end
end
end






