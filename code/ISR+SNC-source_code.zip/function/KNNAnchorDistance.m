function [ A ] = KNNAnchorDistance( X, anchors,k )
%KNNDISTANCE Summary of this function goes here
%   Detailed explanation goes here

% X: each column is a data point
% anchors: each column is a data point

D = L2_distance(X,anchors);
D(D<0) = 0;
if k>=size(anchors,2)
    k=size(anchors,2)-1;
end

eps=1e-8;
[~ , idx] = sort(D, 2); % sort each row
num=size(X,2);
A = zeros(num,k);
for i = 1:num
    id = idx(i,1:k);
    di = D(i, idx(i,1:k+1));
    A(i,id) = (di(k+1)-di(1:k))/(k*di(k+1)-sum(di(1:k))+eps);
end;
clear idx;

end

