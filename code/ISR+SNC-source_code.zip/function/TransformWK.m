function W = TransformWK(A,k,issymmetric)
% A: the original similarity matrix
% k: number of neighbors
% issymmetric: set W = (W+W')/2 if issymmetric=1
% W: similarity matrix

if nargin < 3
    issymmetric = 1;
end;
if nargin < 2
    k = 5;
end;

[~, idx] = sort(A, 2,'descend'); % sort each row

n=size(A,1);
W = zeros(n,size(A,2));
for i = 1:n
    id = idx(i,1:k);
    W(i,id)= A(i, id)./repmat(sum(A(i, id)),[1 length(id)]);
end;
% W=bsxfun(@rdivide,A(:,idx),sum(A(:,idx),2));

W(isnan(W))=1;

if issymmetric == 1
    W = (W+W')/2;
end;


end

