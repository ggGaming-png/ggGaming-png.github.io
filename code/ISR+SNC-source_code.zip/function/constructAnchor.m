function [ biCentSet ] = constructAnchor( X, m, gamma)
% CONSTRUCTANCHOR Summary of this function goes here
%   Detailed explanation goes here

if nargin < 3
    gamma=0.01;
end
[~,~,biCentSet,~] = bikMeans(X,m,2,gamma); 
% showCluster(biDataSet,biK,biCentSet,biClusterAssume);
end

