function[eta] =  etaFunction(t, etaBase, rho, r)
if nargin < 3
    rho = 2;
end
if nargin < 4
    r = 10;
end
if t <= r
   eta = etaBase * (t/r)^rho; 
else
    eta = etaBase;
end
end