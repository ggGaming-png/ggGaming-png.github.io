
n=10;
a=rand(n,1);
e=rand(n,1);
x=EProjSimplex_gereral(a,e);
minobj=sum((a.*x-e).^2);

m=100;
obj=zeros(m,1);
for i=1:1000000
    x1=rand(n,1);
    x1=x1./sum(x1);
    obj(i)=sum((a.*x1-e).^2);
end

sum(obj<minobj)