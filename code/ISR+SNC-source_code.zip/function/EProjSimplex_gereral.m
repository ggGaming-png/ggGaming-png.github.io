function [ x ] = EProjSimplex_gereral( a, e )
%
%% Problem
%
%  min  1/2 || x.*a - e||^2
%  s.t. x>=0, 1'x=1, e >=0
%

h0=a.*a;
not_zero = h0~=0;
e0=e;
a0=a;
x = e;

h=1./h0(not_zero);
e=e(not_zero);
a=a(not_zero);

% h_
h_=h./sum(h);
% u
hea=h.*e.*a;
u=hea + h_.*(1-sum(hea));
% beta_
beta_=rand(1);
% beta_=0;

ITER=100;
for iter=1:ITER
    x1 = u-h_.*beta_;
    posidx = x1>0;
    % fb_    
    fb_ = -sum(h_.*posidx);
    % fb
    fb = sum(x1(posidx))-1;
    
    beta_next_ = beta_-fb./fb_;
    
    beta_ = beta_next_;
    
    x(not_zero) = max(x1,0);
    
%     obj(iter)=fb;
%     obj2(iter)=sum((a0.*x-e0).^2);
    if abs(fb) < 10^-10 
        break;
    end
end

end

