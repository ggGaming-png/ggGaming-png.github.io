% construct similarity matrix with probabilistic k-nearest neighbors. 
%It is a parameter free, distance consistent similarity.
function A_anchor = constructAnchorW_PKN(X, anchors, k)
% X: each column is a data point
% anchors: each column is a data point
% k: number of neighbors
% W: similarity matrix

if nargin < 3
    k = 5;
end;


[~, n] = size(X);
len=size(anchors,2);
if k>=len
    k=len-1;
end


D = L2_distance(X, anchors);
[~, idx] = sort(D, 2); % sort each row

W = zeros(n,len);
for i = 1:n
    id = idx(i,1:k+1);
    di = D(i, id);
    W(i,id) = (di(k+1)-di)/(k*di(k+1)-sum(di(1:k))+eps);
end;
Delta = diag(sum(W)+eps);
A_anchor = W*Delta^-1*W';


end

% for i = 1:n
%     id = idx(i,2:k+2);
%     di = D(i, id);
%     W(i,id) = (di(k+1)-di)/(k*di(k+1)-sum(di(1:k))+eps);
% end;



