function [XL, YL, XU, YU] = semiSplitData( X, Y, ratio )
%Summary of this function goes here
% input:
% X: column data, each column is a record
% Y: row labels, each row represents a label
%   Detailed explanation goes here
% Output:
% XL: label data
% YL: labels for label data
% XU: unlabeled data
% YU: labels for unlabeled data

c=size(Y,2);
nc=cell(c,1);
ns=zeros(c,1);
for i=1:c
    nc{i}=find(Y(:,i)>0);
    ns(i)=max(floor(length(nc{i})*ratio),2);
end


idx=zeros(sum(ns),1);
ptr=1;
for i=1:c
    mat=nc{i};
    idx(ptr:ptr+ns(i)-1)=mat(randsample(length(nc{i}),ns(i)));
    ptr=ptr+ns(i);
end


XL=X(:,idx);
YL=Y(idx,:);
nidx=ones(size(X,2),1);
nidx(idx)=0;
XU=X(:,nidx>0);
YU=Y(nidx>0,:);
end

