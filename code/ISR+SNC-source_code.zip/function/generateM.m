function [ m ] = generateM( d )
%GENERATEM Summary of this function goes here
%   Detailed explanation goes here
% input:
% d: the number of features
if d>=2000
    m=[50 100 200];
else if d>200
        m=20:20:200;
    else if  d>100
            m=10:10:100;
        else if d>50
                m=5:5:50;
            else
                step=floor((size(X,2)-2)/10);
                if step>1
                    m=step:step:10*step;
                else
                    m=2:size(X,2);
                end
            end
        end
    end
end
end

