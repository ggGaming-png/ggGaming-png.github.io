% compute l_{2,1} norm
% ||A||_{2,1}
function v = L21norm(A, epsilon)
% a: each column is a data
% d:  norm value
if nargin<3
    epsilon=0;
end

v=sum((sum(A.*A,2)+epsilon).^(1/2));