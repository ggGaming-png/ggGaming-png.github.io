function  showCluster( dataSet,k,centroids,clusterAssment )
%SHOWCLUSTER Summary of this function goes here
%   Detailed explanation goes here
[numSamples, dim] = size(dataSet(:,1:2));
mark = ['g', 'r', 'b','y','m','c','g','r','b'];

% ,mark(mod(markIndex, length(mark))+1),'filled'
figure;
for cs = unique(clusterAssment(:,1))';
    markIndex = find(clusterAssment(:,1)==cs);
    scatter(dataSet(markIndex, 1), dataSet(markIndex, 2),5)
    hold on;
end
for i =1:k
    scatter(centroids(i, 1), centroids(i, 2),110,'k');
end


end

