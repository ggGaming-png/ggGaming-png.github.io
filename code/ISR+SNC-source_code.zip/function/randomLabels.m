function [ Y ] = randomLabels( n,class_num )
%LABELFORMAT Summary of this function goes here
%   Detailed explanation goes here

StartInd = randsrc(n,1,1:class_num);

Y= zeros(n,class_num);
for i=1:n
    Y(i,StartInd(i))=1;
end
end

